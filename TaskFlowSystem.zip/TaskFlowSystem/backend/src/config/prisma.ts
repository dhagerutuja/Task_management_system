import { PrismaClient } from "../../generated/prisma";
import { DATABASE_URL } from "./env";
import { PrismaPg } from "@prisma/adapter-pg";

declare global {
  // allow global __prisma for hot-reloading in dev
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

const prisma =
  global.__prisma ??
  new PrismaClient({
    adapter: new PrismaPg({ connectionString: DATABASE_URL }),
  });

if (process.env.NODE_ENV !== "production") global.__prisma = prisma;

export default prisma;
