import dotenv from "dotenv";

dotenv.config();

export const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;
export const DATABASE_URL =
  process.env.DATABASE_URL || "postgresql://rutujadhage@localhost:5432/taskdb";
export const AUTH_SECRET = process.env.AUTH_SECRET || "change_me_dev_secret";

export default {
  PORT,
  DATABASE_URL,
  AUTH_SECRET,
};
