import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { AUTH_SECRET } from "../config/env";

export type AuthRequest = Request & { user: { id: string; email?: string } };

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers["authorization"] as string | undefined;
  if (!auth || !auth.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });

  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, AUTH_SECRET) as any;
    // attach to req
    (req as any).user = { id: payload.sub as string, email: payload.email };
    return next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid token" });
  }
}

export default requireAuth;
