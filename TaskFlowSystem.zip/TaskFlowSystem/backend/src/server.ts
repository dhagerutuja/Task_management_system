import app from "./app";
import { PORT } from "./config/env";

const port = PORT || 4000;

app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Server listening on http://localhost:${port}`);
});
