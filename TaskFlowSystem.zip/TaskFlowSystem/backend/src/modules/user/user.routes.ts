import { Router } from "express";

const router = Router();

// TODO: add user endpoints (register, login, profile)

export default router;
