import { Request, Response, NextFunction } from "express";
import * as service from "./auth.service";
import { AUTH_SECRET } from "../../config/env";

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, password } = req.body as { email: string; password: string };
    if (!email || !password) return res.status(400).json({ error: "email and password required" });

    try {
      const result = await service.registerUser(email, password, AUTH_SECRET);
      return res.status(201).json({ accessToken: result.token });
    } catch (err: any) {
      // Prisma unique constraint error code is usually P2002
      if (err?.code === "P2002" || err?.message?.includes("unique")) {
        return res.status(409).json({ error: "Email already in use" });
      }
      throw err;
    }
  } catch (err) {
    next(err);
  }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, password } = req.body as { email: string; password: string };
    if (!email || !password) return res.status(400).json({ error: "email and password required" });

    try {
      const result = await service.loginUser(email, password, AUTH_SECRET);
      return res.status(200).json({ accessToken: result.token });
    } catch (err: any) {
      if (err?.message === "INVALID_CREDENTIALS") return res.status(401).json({ error: "Invalid credentials" });
      throw err;
    }
  } catch (err) {
    next(err);
  }
}
