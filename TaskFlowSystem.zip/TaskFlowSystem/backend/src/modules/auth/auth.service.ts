import prisma from "../../config/prisma";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { AUTH_SECRET } from "../../config/env";

const SALT_ROUNDS = 10;

export interface AuthResult {
  token: string;
}

export async function registerUser(email: string, password: string, jwtSecret: string = AUTH_SECRET): Promise<AuthResult> {
  const hashed = await bcrypt.hash(password, SALT_ROUNDS);

  const user = await prisma.user.create({
    data: {
      email,
      password: hashed,
    },
  });

  const token = jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: "1h" });

  return { token };
}

export async function loginUser(email: string, password: string, jwtSecret: string = AUTH_SECRET): Promise<AuthResult> {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) throw new Error("INVALID_CREDENTIALS");

  const ok = await bcrypt.compare(password, user.password);
  if (!ok) throw new Error("INVALID_CREDENTIALS");

  const token = jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: "1h" });

  return { token };
}
