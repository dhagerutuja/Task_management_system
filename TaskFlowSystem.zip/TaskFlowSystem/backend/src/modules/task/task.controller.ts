import { Response, NextFunction, RequestHandler } from "express";
import * as service from "./task.service";
import { AuthRequest } from "../../middleware/auth";

export const createTask: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { title, description, dueDate, priority } = req.body as { title: string; description?: string; dueDate?: string; priority?: "LOW" | "MEDIUM" | "HIGH" };
    if (!title) return res.status(400).json({ error: "title required" });
    const task = await service.createTask({ title, description, dueDate: dueDate ?? null, priority, userId: r.user.id });
    return res.status(201).json(task);
  } catch (err) {
    next(err);
  }
};

export const listTasks: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { status, search, page, pageSize } = req.query as any;
    const result = await service.getTasks(r.user.id, {
      status: status as any,
      search: search as string | undefined,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
    return res.json(result);
  } catch (err) {
    next(err);
  }
};

export const patchTask: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { id } = req.params as { id: string };
    const data = req.body as Partial<{ title: string; description: string; status: any; dueDate?: string | null; priority?: "LOW" | "MEDIUM" | "HIGH" }>;
    const updated = await service.updateTask(id, r.user.id, data);
    if (!updated) return res.status(404).json({ error: "Not found" });
    return res.json(updated);
  } catch (err) {
    next(err);
  }
};

export const reorderTasks: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { orderedIds } = req.body as { orderedIds: string[] };
    if (!Array.isArray(orderedIds)) return res.status(400).json({ error: "orderedIds required" });
    await service.reorderTasks(r.user.id, orderedIds);
    return res.json({ ok: true });
  } catch (err) {
    next(err);
  }
};

export const deleteTask: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { id } = req.params as { id: string };
    const ok = await service.deleteTask(id, r.user.id);
    if (!ok) return res.status(404).json({ error: "Not found" });
    return res.status(204).send();
  } catch (err) {
    next(err);
  }
};

export const toggleTask: RequestHandler = async (req, res, next) => {
  const r = req as AuthRequest;
  try {
    const { id } = req.params as { id: string };
    const t = await service.toggleTask(id, r.user.id);
    if (!t) return res.status(404).json({ error: "Not found" });
    return res.json(t);
  } catch (err) {
    next(err);
  }
};
