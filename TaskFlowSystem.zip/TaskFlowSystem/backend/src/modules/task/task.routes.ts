import { Router } from "express";
import * as controller from "./task.controller";
import requireAuth from "../../middleware/auth";

const router = Router();

router.use(requireAuth);

router.post("/", controller.createTask);
router.get("/", controller.listTasks);
router.patch("/reorder", controller.reorderTasks);
router.patch("/:id", controller.patchTask);
router.delete("/:id", controller.deleteTask);
router.patch("/:id/toggle", controller.toggleTask);

export default router;
 
