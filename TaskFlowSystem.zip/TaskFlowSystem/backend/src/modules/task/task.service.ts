import prisma from "../../config/prisma";

export interface CreateTaskInput {
  title: string;
  description?: string | null;
  userId: string;
  dueDate?: string | null;
  priority?: "LOW" | "MEDIUM" | "HIGH";
}

export async function createTask(input: CreateTaskInput) {
  // determine order: place at end if not provided
  const maxOrder = await prisma.task.findFirst({ where: { userId: input.userId }, orderBy: { order: "desc" }, select: { order: true } });
  const nextOrder = typeof maxOrder?.order === "number" ? (maxOrder!.order! + 1) : 1;

  return prisma.task.create({
    data: {
      title: input.title,
      description: input.description,
      userId: input.userId,
      dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
      priority: input.priority as any,
      order: nextOrder,
    },
  });
}

export async function getTasks(userId: string, opts: { status?: string; search?: string; page?: number; pageSize?: number }) {
  const where: any = { userId };
  if (opts.status) where.status = opts.status;
  if (opts.search) where.title = { contains: opts.search, mode: "insensitive" };

  const page = opts.page && opts.page > 0 ? opts.page : 1;
  const pageSize = opts.pageSize && opts.pageSize > 0 ? opts.pageSize : 10;

  const [items, total] = await Promise.all([
    prisma.task.findMany({ where, skip: (page - 1) * pageSize, take: pageSize, orderBy: { order: "asc" } }),
    prisma.task.count({ where }),
  ]);

  // compute overdue flag
  const now = new Date();
  const itemsWithOverdue = items.map((t) => ({ ...t, overdue: t.status === "PENDING" && t.dueDate ? t.dueDate < now : false }));

  return { items: itemsWithOverdue, total, page, pageSize };
}

export async function getTaskById(id: string) {
  return prisma.task.findUnique({ where: { id } });
}

export async function updateTask(id: string, userId: string, data: Partial<{ title: string; description: string; status: string; dueDate?: string | null; priority?: "LOW" | "MEDIUM" | "HIGH" }>) {
  const task = await prisma.task.findUnique({ where: { id } });
  if (!task || task.userId !== userId) return null;
  const payload: any = { ...data };
  if (data && (data as any).dueDate) payload.dueDate = new Date((data as any).dueDate);
  if (data && (data as any).priority) payload.priority = (data as any).priority;
  return prisma.task.update({ where: { id }, data: payload as any });
}

export async function deleteTask(id: string, userId: string) {
  const task = await prisma.task.findUnique({ where: { id } });
  if (!task || task.userId !== userId) return null;
  await prisma.task.delete({ where: { id } });
  return true;
}

export async function toggleTask(id: string, userId: string) {
  const task = await prisma.task.findUnique({ where: { id } });
  if (!task || task.userId !== userId) return null;
  const next = task.status === "PENDING" ? "DONE" : "PENDING";
  return prisma.task.update({ where: { id }, data: { status: next as any } as any });
}

export async function reorderTasks(userId: string, orderedIds: string[]) {
  // update each task order according to index in orderedIds
  const updates = orderedIds.map((id, idx) => prisma.task.updateMany({ where: { id, userId }, data: { order: idx + 1 } }));
  await Promise.all(updates);
  return true;
}
