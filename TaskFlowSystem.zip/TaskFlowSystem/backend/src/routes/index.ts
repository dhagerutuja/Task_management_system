import { Router } from "express";
import userRouter from "../modules/user/user.routes";
import taskRouter from "../modules/task/task.routes";
import authRouter from "../modules/auth/auth.routes";

const router = Router();

router.get("/", (_req, res) => {
  res.json({ ok: true });
});

router.use("/users", userRouter);
router.use("/tasks", taskRouter);
router.use("/auth", authRouter);

export default router;
