# Frontend

Next.js frontend for the Task Management app.

Run (from frontend/):

```bash
npm install
npm run dev
```

Open http://localhost:3000
