"use client";
import Link from "next/link";

export default function Home() {
  return (
    <main className="container" style={{ paddingTop: 28 }}>
      <section className="card" style={{ display: "flex", gap: 24, alignItems: "center", padding: 36 }}>
        <div style={{ flex: 1 }}>
          <h1 style={{ fontSize: 34, margin: 0 }}>Organize Your Work &amp; Boost Productivity</h1>
          <p className="app-sub">The ultimate task management app to help you stay organized and get things done efficiently.</p>
          <div style={{ display: "flex", gap: 12, marginTop: 18 }}>
            <Link href="/register"><button className="primary-btn">Register Here</button></Link>
            <Link href="/login"><button style={{ padding: "10px 16px", borderRadius: 12, border: "1px solid #e6e9ef", background: "transparent" }}>Log In</button></Link>
          </div>
        </div>
        <div style={{ width: 420, textAlign: "center" }}>
          <img src="/landingpageimg.webp" alt="dashboard mock" style={{ width: "100%", borderRadius: 12, transform: "translateY(-6px)", boxShadow: "0 18px 40px rgba(2,6,23,0.08)" }} />
        </div>
      </section>

      <section id="features" style={{ marginTop: 28 }}>
        <h2>Features</h2>
        <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
          <div className="card" style={{ flex: 1, textAlign: "left" }}>
            <div className="stat-title">Easily Manage Tasks</div>
            <p>Quickly create, organize, and complete tasks.</p>
          </div>
          <div className="card" style={{ flex: 1 }}>
            <div className="stat-title">Collaborate with Your Team</div>
            <p>Share tasks and work together seamlessly.</p>
          </div>
          <div className="card" style={{ flex: 1 }}>
            <div className="stat-title">Track Your Progress</div>
            <p>Monitor your productivity and goals.</p>
          </div>
        </div>
      </section>

      <section id="about" style={{ marginTop: 28 }}>
        <h2>About</h2>
        <p className="app-sub">TaskFlow is designed to be lightweight, fast, and easy to use — built for individuals and teams.</p>
      </section>
    </main>
  );
}
