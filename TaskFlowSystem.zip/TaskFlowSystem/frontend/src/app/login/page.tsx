"use client";
import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { login } from "../../lib/auth";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const emailValid = useMemo(() => emailRegex.test(email), [email]);
  const canSubmit = emailValid && password.length > 0;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await login(email, password);
      router.push("/dashboard");
    } catch (e: any) {
      setErr(e?.message || "Login failed");
    }
  }

  return (
    <div className="auth-viewport">
      <div className="auth-card">
        <div className="brand-block">
          <div className="brand-logo">TF</div>
          <div className="app-name">TaskFlow</div>
          <div className="app-sub">Welcome to your task manager</div>
        </div>

        {err && <div className="error">{err}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input className={`form-input ${email && !emailValid ? "invalid" : ""}`} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
            {email && !emailValid ? <div className="hint invalid">Please enter a valid email address.</div> : null}
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" />
            <div className="pw-checks">
              <div className={`pw-check ${/[A-Z]/.test(password) ? "valid" : "invalid"}`}>At least one uppercase letter</div>
              <div className={`pw-check ${/[a-z]/.test(password) ? "valid" : "invalid"}`}>At least one lowercase letter</div>
              <div className={`pw-check ${/[0-9]/.test(password) ? "valid" : "invalid"}`}>At least one number</div>
              <div className={`pw-check ${password.length >= 6 ? "valid" : "invalid"}`}>At least 6 characters</div>
            </div>
          </div>

          <div style={{ marginTop: 6 }}>
            <button className="primary-btn" type="submit" disabled={!canSubmit}>
              Sign In
            </button>
          </div>
        </form>

        <div style={{ marginTop: 12, textAlign: "center" }}>
          <a href="/register" className="hint">New here? Create account</a>
        </div>
      </div>
    </div>
  );
}
