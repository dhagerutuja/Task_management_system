"use client";
import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { register } from "../../lib/auth";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const emailValid = useMemo(() => emailRegex.test(email), [email]);
  const strongPassword = useMemo(() => /[A-Z]/.test(password) && /[a-z]/.test(password) && /[0-9]/.test(password) && password.length >= 6, [password]);
  const canSubmit = name.trim().length > 0 && emailValid && strongPassword;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await register(name, email, password);
      router.push("/dashboard");
    } catch (e: any) {
      setErr(e?.message || "Register failed");
    }
  }

  return (
    <div className="auth-viewport">
      <div className="auth-card">
        <div className="brand-block">
          <div className="brand-logo">TF</div>
          <div className="app-name">TaskFlow</div>
          <div className="app-sub">Welcome to your task manager</div>
        </div>

        {err && <div className="error">{err}</div>}
        <form onSubmit={submit}>
          <div className="form-group">
            <label className="form-label">Name</label>
            <input className={`form-input ${name === "" ? "invalid" : ""}`} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" />
            {name === "" ? <div className="hint invalid">Name is required.</div> : null}
          </div>

          <div className="form-group">
            <label className="form-label">Email</label>
            <input className={`form-input ${email && !emailValid ? "invalid" : ""}`} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
            {email && !emailValid ? <div className="hint invalid">Please enter a valid email address.</div> : null}
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Create a password" />
            <div className="pw-checks">
              <div className={`pw-check ${/[A-Z]/.test(password) ? "valid" : "invalid"}`}>At least one uppercase letter</div>
              <div className={`pw-check ${/[a-z]/.test(password) ? "valid" : "invalid"}`}>At least one lowercase letter</div>
              <div className={`pw-check ${/[0-9]/.test(password) ? "valid" : "invalid"}`}>At least one number</div>
              <div className={`pw-check ${password.length >= 6 ? "valid" : "invalid"}`}>At least 6 characters</div>
            </div>
          </div>

          <div style={{ marginTop: 6 }}>
            <button className="primary-btn" type="submit" disabled={!canSubmit}>
              Create Account
            </button>
          </div>
        </form>

        <div style={{ marginTop: 12, textAlign: "center" }}>
          <a href="/login" className="hint">Already have an account? Sign in</a>
        </div>
      </div>
    </div>
  );
}
