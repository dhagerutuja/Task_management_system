"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getTasks, createTask, toggleTask, deleteTask, reorderTasks } from "../../lib/api";
import { getToken } from "../../lib/auth";
import type { Task, TaskCreateInput } from "../../types";
import TaskForm from "../../components/TaskForm";
import TaskList from "../../components/TaskList";
import AnalyticsCharts from "../../components/AnalyticsCharts";

export default function Dashboard() {
  const router = useRouter();
  const token = getToken();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    if (!token) return router.push("/login");
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    const res = await getTasks({ search, status });
    setTasks((res.items || []) as Task[]);
  }

  async function onCreate(data: TaskCreateInput) {
    await createTask(data as any);
    await load();
  }

  async function onToggle(id: string) {
    await toggleTask(id);
    await load();
  }

  async function onDelete(id: string) {
    await deleteTask(id);
    await load();
  }

  async function onReorder(orderedIds: string[]) {
    // optimistic update
    const idToOrder: Record<string, number> = {};
    orderedIds.forEach((id, idx) => (idToOrder[id] = idx + 1));
    setTasks((prev) => prev.map((t) => ({ ...t, order: idToOrder[t.id] ?? t.order })).sort((a, b) => (a.order ?? 0) - (b.order ?? 0)));
    await reorderTasks(orderedIds);
    await load();
  }

  const total = tasks.length;
  const completed = tasks.filter((t) => t.status === "DONE").length;
  const pending = tasks.filter((t) => t.status === "PENDING").length;
  const overdue = tasks.filter((t) => t.overdue).length;

  return (
    <div className="page">
      <h2>Dashboard</h2>
      <div className="card" style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div>
            <h3 style={{ margin: 0 }}>Dashboard</h3>
            <div className="app-sub">Track your productivity</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="primary-btn" onClick={() => load()}>Refresh</button>
            <button onClick={() => { /* placeholder for settings */ }}>Settings</button>
          </div>
        </div>
      </div>

      <section className="card stats-row">
        <div className="stat">
          <div className="stat-title">Total</div>
          <div className="stat-value">{total}</div>
        </div>
        <div className="stat">
          <div className="stat-title">Completed</div>
          <div className="stat-value">{completed}</div>
        </div>
        <div className="stat">
          <div className="stat-title">Pending</div>
          <div className="stat-value">{pending}</div>
        </div>
        <div className="stat">
          <div className="stat-title">Overdue</div>
          <div className="stat-value">{overdue}</div>
        </div>
      </section>
      <section className="card">
        <TaskForm onCreate={onCreate} />
        <div className="filters">
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search title" />
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="PENDING">Pending</option>
            <option value="DONE">Done</option>
          </select>
          <button onClick={load}>Apply</button>
        </div>

        <AnalyticsCharts tasks={tasks} />
      </section>

      <section className="card">
        <TaskList tasks={tasks.sort((a,b)=> (a.order ?? 0)-(b.order ?? 0))} onToggle={onToggle} onDelete={onDelete} onReorder={onReorder} />
      </section>
    </div>
  );
}
