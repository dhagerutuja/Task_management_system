"use client";
import React from "react";
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { arrayMove, SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import SortableItem from "./_SortableItem";
import type { Task } from "../types";

export default function TaskList({ tasks, onToggle, onDelete, onReorder }: { tasks: Task[]; onToggle: (id: string) => void; onDelete: (id: string) => void; onReorder: (orderedIds: string[]) => Promise<void> }) {
  const sensors = useSensors(useSensor(PointerSensor));

  const handleDragEnd = ({ active, over }: any) => {
    if (!over || active.id === over.id) return;
    const oldIndex = tasks.findIndex((t) => t.id === active.id);
    const newIndex = tasks.findIndex((t) => t.id === over.id);
    const newOrder = arrayMove(tasks, oldIndex, newIndex);
    const orderedIds = newOrder.map((t) => t.id);
    // optimistic UI handled by parent; call reorder
    onReorder(orderedIds).catch(() => {});
  };

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={tasks.map((t) => t.id)} strategy={verticalListSortingStrategy}>
        <ul className="task-list">
          {tasks.map((t) => (
            <SortableItem key={t.id} id={t.id}>
              <li className={t.status === "DONE" ? "done" : "pending"}>
                <div>
                  <strong>{t.title}</strong>
                  <div className="muted">{t.description}</div>
                  <div className="task-meta">
                    {t.dueDate ? <span className="due">Due: {new Date(t.dueDate).toLocaleDateString()}</span> : null}
                    <span className={`badge priority ${t.priority ? t.priority.toLowerCase() : "medium"}`}>{t.priority ?? "MEDIUM"}</span>
                    {t.overdue ? <span className="badge overdue">Overdue</span> : null}
                  </div>
                </div>
                <div className="actions">
                  <button onClick={() => onToggle(t.id)}>{t.status === "DONE" ? "Mark Pending" : "Mark Done"}</button>
                  <button onClick={() => onDelete(t.id)}>Delete</button>
                </div>
              </li>
            </SortableItem>
          ))}
        </ul>
      </SortableContext>
    </DndContext>
  );
}
