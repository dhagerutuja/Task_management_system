"use client";
import React from "react";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from "recharts";
import type { Task } from "../types";

const COLORS = ["#10b981", "#2563eb", "#ef4444"];

export default function AnalyticsCharts({ tasks }: { tasks: Task[] }) {
  const completed = tasks.filter((t) => t.status === "DONE").length;
  const pending = tasks.filter((t) => t.status === "PENDING").length;
  const overdue = tasks.filter((t) => t.overdue).length;

  const pieData = [
    { name: "Completed", value: completed },
    { name: "Pending", value: pending },
    { name: "Overdue", value: overdue },
  ];

  const priorityCounts = [
    { priority: "LOW", count: tasks.filter((t) => t.priority === "LOW").length },
    { priority: "MEDIUM", count: tasks.filter((t) => t.priority === "MEDIUM").length },
    { priority: "HIGH", count: tasks.filter((t) => t.priority === "HIGH").length },
  ];

  return (
    <div style={{ display: "flex", gap: 12, marginTop: 16, flexWrap: "wrap" }}>
      <div className="card" style={{ flex: "1 1 320px", minHeight: 240 }}>
        <h3>Task Status</h3>
        <div style={{ width: "100%", height: 200 }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={40} outerRadius={70} paddingAngle={4}>
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card" style={{ flex: "1 1 420px", minHeight: 240 }}>
        <h3>Tasks by Priority</h3>
        <div style={{ width: "100%", height: 200 }}>
          <ResponsiveContainer>
            <BarChart data={priorityCounts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="priority" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#2563eb" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
