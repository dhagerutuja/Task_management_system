"use client";
import React, { useState } from "react";
import type { TaskCreateInput } from "../types";

export default function TaskForm({ onCreate }: { onCreate: (data: TaskCreateInput) => Promise<void> }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState<string | undefined>(undefined);
  const [priority, setPriority] = useState<"LOW" | "MEDIUM" | "HIGH">("MEDIUM");

  return (
    <form
      className="task-form"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!title) return;
        await onCreate({ title, description: description || undefined, dueDate: dueDate || null, priority });
        setTitle("");
        setDescription("");
        setDueDate(undefined);
        setPriority("MEDIUM");
      }}
    >
      <input className="form-input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="New task title" />
      <input className="form-input" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description (optional)" />
      <input className="form-input" type="date" value={dueDate ?? ""} onChange={(e) => setDueDate(e.target.value || undefined)} />
      <select className="form-input" value={priority} onChange={(e) => setPriority(e.target.value as any)}>
        <option value="LOW">Low</option>
        <option value="MEDIUM">Medium</option>
        <option value="HIGH">High</option>
      </select>
      <button className="primary-btn" type="submit">Add</button>
    </form>
  );
}
