"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { logout, getToken } from "../lib/auth";
import { useTheme } from "../lib/ThemeProvider";

export default function Navbar() {
  const router = useRouter();
  const token = getToken();
  const { theme, toggle } = useTheme();

  function doLogout() {
    logout();
    router.push("/login");
  }

  return (
    <nav className="nav">
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div className="brand-logo" style={{ width: 36, height: 36, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontWeight: 700 }}>TF</div>
        <div className="brand">TaskFlow</div>
      </div>
      <div className="links">
        <a href="#features">Features</a>
        <a href="#about">About</a>
        <button className="theme-toggle" onClick={toggle} aria-label="Toggle theme">{theme === "dark" ? "🌙" : "☀️"}</button>
        {token ? (
          <>
            <Link href="/dashboard">Dashboard</Link>
            <button onClick={doLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link href="/login">Login</Link>
            <Link href="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
