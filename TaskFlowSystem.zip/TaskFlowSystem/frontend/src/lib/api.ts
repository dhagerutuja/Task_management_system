const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";

function authHeaders() {
  const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function post(path: string, body: any) {
  const res = await fetch(BASE + path, { method: "POST", headers: { "Content-Type": "application/json", ...authHeaders() }, body: JSON.stringify(body) });
  return res.json();
}

export async function get(path: string) {
  const res = await fetch(BASE + path, { headers: { ...authHeaders() } });
  return res.json();
}

export async function del(path: string) {
  const res = await fetch(BASE + path, { method: "DELETE", headers: { ...authHeaders() } });
  return res;
}

export async function patchReq(path: string, body?: any) {
  const res = await fetch(BASE + path, { method: "PATCH", headers: { "Content-Type": "application/json", ...authHeaders() }, body: body ? JSON.stringify(body) : undefined });
  return res.json();
}

// Task helpers
export async function getTasks(opts?: { search?: string; status?: string }) {
  const q = new URLSearchParams();
  if (opts?.search) q.set("search", opts.search);
  if (opts?.status) q.set("status", opts.status);
  return (await get(`/api/tasks?${q.toString()}`));
}

export async function createTask(body: any) {
  return (await post(`/api/tasks`, body));
}

export async function reorderTasks(orderedIds: string[]) {
  return await patchReq(`/api/tasks/reorder`, { orderedIds });
}

export async function toggleTask(id: string) {
  return (await patchReq(`/api/tasks/${id}/toggle`));
}

export async function deleteTask(id: string) {
  return (await del(`/api/tasks/${id}`));
}
