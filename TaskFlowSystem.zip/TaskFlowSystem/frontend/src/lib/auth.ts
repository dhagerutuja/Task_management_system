export async function login(email: string, password: string) {
  const res = await fetch("http://localhost:4000/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
  if (!res.ok) throw new Error("Login failed");
  const data = await res.json();
  localStorage.setItem("token", data.accessToken);
}

export async function register(name: string, email: string, password: string) {
  const res = await fetch("http://localhost:4000/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, password }) });
  if (!res.ok) throw new Error("Register failed");
  const data = await res.json();
  localStorage.setItem("token", data.accessToken);
}

export function logout() {
  localStorage.removeItem("token");
}

export function getToken() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("token");
}
