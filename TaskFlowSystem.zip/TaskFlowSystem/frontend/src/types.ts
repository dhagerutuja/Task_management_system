export type Task = {
  id: string;
  title: string;
  description?: string | null;
  status: "PENDING" | "DONE";
  dueDate?: string | null;
  priority?: "LOW" | "MEDIUM" | "HIGH";
  order?: number | null;
  overdue?: boolean;
};

export type TaskCreateInput = {
  title: string;
  description?: string;
  dueDate?: string | null;
  priority?: "LOW" | "MEDIUM" | "HIGH";
};
